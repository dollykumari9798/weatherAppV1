let data ={
  
    "cloud_pct": 75,
    "temp": 5,
    "feels_like": 2,
    "humidity": 81,
    "min_temp": 3,
    "max_temp": 6,
    "wind_speed": 3.09,
    "wind_degrees": 170,
    "sunrise": 1681909984,
    "sunset": 1681959807
  }
  console.log(data);
  let dset = document.getElementById('dataset');
  dset.style.backgroundColor='red';